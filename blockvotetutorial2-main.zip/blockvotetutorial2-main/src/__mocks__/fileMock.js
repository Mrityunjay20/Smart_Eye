// NOTE: This is used to mock resource imports in JSX for tests
module.exports = '' 

